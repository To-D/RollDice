#ifndef Dice_H
#define Dice_H

class Dice{
    public:
    Dice();
    ~Dice();
    int roll();
};

#endif